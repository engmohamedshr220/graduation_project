from .base import *

DEBUG = env.bool("DEBUG")


ALLOWED_HOSTS = ['*','localhost'] # Allow all hosts for development purposes

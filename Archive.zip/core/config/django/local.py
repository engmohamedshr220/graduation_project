from .base import *


DEBUG = env.bool("DEBUG")


ALLOWED_HOSTS = ['*','localhost']

from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('city/', include("city.urls")),
    path('accounts/', include("accounts.urls")),
    path('tweets/', include("stories.urls")),
    path('clinic/', include("clinic.urls")),
    path('chat/', include("chat.urls")),
    path('schema/', SpectacularAPIView.as_view(), name='schema'),
    path('schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]
